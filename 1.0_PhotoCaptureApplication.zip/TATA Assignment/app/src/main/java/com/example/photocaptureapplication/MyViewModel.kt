package com.example.photocaptureapplication

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent

import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat.startActivityForResult
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class MyViewModel:ViewModel() {
    private val _showBottomSheet = MutableStateFlow(false)
    val showBottomSheet: StateFlow<Boolean> = _showBottomSheet
    val VIDEO_CAPTURE_REQUEST_CODE = 1001
    private lateinit var imageCapture: ImageCapture
    private lateinit var videoCapture: VideoCapture<Recorder>
    private lateinit var scheduler: ScheduledExecutorService

    var _videoUri = mutableStateOf<Uri?>(null)
    //private val _videoUri = MutableLiveData<Uri>()


    private val REQUEST_VIDEO_CAPTURE = 1
    private val _items = MutableStateFlow(
        listOf(
            BottomSheetItem("Resolution", Icons.Default.Face),
            BottomSheetItem("Frame Rate", Icons.Default.Star),
            BottomSheetItem("Torch on/off", Icons.Default.Favorite),
            BottomSheetItem("Custom picture clicker", Icons.Default.Add),
            BottomSheetItem("About", Icons.Default.Info)
        )
    )
    val items: StateFlow<List<BottomSheetItem>> = _items

    fun toggleBottomSheet(show: Boolean) {
        _showBottomSheet.value = show
    }

    fun onItemClick(itemIndex: Int) {
        // Handle item click
        // For example, log the click or update some state
        viewModelScope.launch {
            if(itemIndex==0){

            }else if(itemIndex==1){

            }else if(itemIndex==2){

            }else if(itemIndex==3){

            }else if(itemIndex==4){

            }
        }
    }

    @OptIn(ExperimentalPermissionsApi::class)
    @Composable
    fun cameraPermissionHandler() {
        val cameraPermissionState = rememberPermissionState(android.Manifest.permission.CAMERA)


        LaunchedEffect(Unit) {

            cameraPermissionState.launchPermissionRequest()

        }

        val cameraPermissionsGranted = cameraPermissionState.status.isGranted

        if (cameraPermissionsGranted) {
            storagepermissionhandler()
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Permissions are required to use this application.")
            }
        }
    }

    @OptIn(ExperimentalPermissionsApi::class)
    @Composable
    fun storagepermissionhandler(){
        val storagePermissionsState = rememberMultiplePermissionsState(
            permissions = listOf(
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        )

        LaunchedEffect(Unit) {
            storagePermissionsState.launchMultiplePermissionRequest()
        }

        val storagePermissionsGranted = storagePermissionsState.allPermissionsGranted

    }


    fun createImageUri(context: Context): Uri {
        val contentResolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "image_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        }
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)!!
    }

    fun createVideoUri(context: Context): Uri {
        val contentResolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "video_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/Camera")
        }
        return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)!!
    }



    fun dispatchTakeVideoIntent(context: Context, requestCode: Int) {
        Intent(MediaStore.ACTION_VIDEO_CAPTURE).also { takeVideoIntent ->
            takeVideoIntent.resolveActivity(context.packageManager)?.also {
//                context.startActivityForResult(takeVideoIntent, requestCode)
                if (context is Activity) {
                    context.startActivityForResult(takeVideoIntent, requestCode)
                } else {
                    throw IllegalArgumentException("Context must be an instance of Activity")
                }
            }
        }
    }

    fun handleVideoCaptureResult(requestCode: Int, resultCode: Int, data: Intent?,context: Context) {
        if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == Activity.RESULT_OK) {
            val videoUri: Uri? = data?.data
            _videoUri.value = videoUri
            if (videoUri != null) {
                _videoUri.value = videoUri
                saveVideoToInternalStorage(videoUri,context)
            }
        }
    }
    private fun saveVideoToInternalStorage(videoUri: Uri, context: Context) {
        val inputStream = context.contentResolver.openInputStream(videoUri)
        val outputFile = File(context.filesDir, "captured_video.mp4")
        val outputStream = FileOutputStream(outputFile)
        inputStream?.use { input ->
            outputStream.use { output ->
                input.copyTo(output)
            }
        }
        outputStream.close()
        inputStream?.close()
        Log.d("MyViewModel", "Video saved to: ${outputFile.absolutePath}")
    }


    fun initialize(imageCapture: ImageCapture, videoCapture: VideoCapture<Recorder>) {
        this.imageCapture = imageCapture
        this.videoCapture = videoCapture
    }

    fun startRecording(context: Context) {
        val videoFile = File(getOutputDirectory(context), "${System.currentTimeMillis()}.mp4")
        val outputOptions = FileOutputOptions.Builder(videoFile).build()
        val recording = videoCapture.output.prepareRecording(context, outputOptions)
            .start(ContextCompat.getMainExecutor(context)) { recordEvent ->
                when (recordEvent) {
                    is VideoRecordEvent.Start -> {
                        scheduleImageCapture(context)
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (!recordEvent.hasError()) {
                            _videoUri.value = Uri.fromFile(videoFile)
                        } else {
                            Log.e("CameraViewModel", "Video capture error: ${recordEvent.error}")
                        }
                        stopScheduledImageCapture()
                    }
                }
            }
    }

    fun stopRecording() {
        // Logic to stop recording
    }

    private fun scheduleImageCapture(context: Context) {
        scheduler = Executors.newScheduledThreadPool(1)
        val captureTask = Runnable { capturePhoto(context) }
        scheduler.scheduleAtFixedRate(captureTask, 0, 5, TimeUnit.SECONDS)
    }

    private fun stopScheduledImageCapture() {
        if (::scheduler.isInitialized) {
            scheduler.shutdown()
        }
    }

    private fun capturePhoto(context: Context) {
        val photoFile = File(getOutputDirectory(context), "${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    val savedUri = Uri.fromFile(photoFile)
                    Log.d("CameraViewModel", "Photo capture succeeded: $savedUri")
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("CameraViewModel", "Photo capture failed: ${exception.message}", exception)
                }
            }
        )
    }

    private fun getOutputDirectory(context: Context): File {
        val mediaDir = context.externalMediaDirs.firstOrNull()?.let {
            File(it, context.resources.getString(R.string.app_name)).apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists()) mediaDir else context.filesDir
    }

}